export CC=$TOOLCHAIN_TOP/usr/bin/mips-linux-gcc
export AS=$TOOLCHAIN_TOP/usr/bin/mips-linux-as
export LD=$TOOLCHAIN_TOP/usr/bin/mips-linux-ld
export AR=$TOOLCHAIN_TOP/usr/bin/mips-linux-ar
export NM=$TOOLCHAIN_TOP/usr/bin/mips-linux-nm
export STRIP=$TOOLCHAIN_TOP/usr/bin/mips-linux-strip
export OBJDUMP=$TOOLCHAIN_TOP/usr/bin/mips-linux-objdump
export RANLIB=$TOOLCHAIN_TOP/usr/bin/mips-linux-ranlib
export STD_INC=$TOOLCHAIN_TOP/usr/include
export GCC_INC=$TOOLCHAIN_TOP/usr/include
#export CFLAGS=-I/projects/stbbsp/jayeshp/cm/CmLinux338xVer106_ps/userspace/gpl/apps/staging/usr/local/include
#export LDFLAGS='-L/projects/stbbsp/jayeshp/cm/CmLinux338xVer106_ps/userspace/gpl/apps/staging/usr/local/lib -L/projects/stbbsp/jayeshp/cm/CmLinux338xVer106_ps/userspace/private/apps/dlna/lib'
#export PKG_CONFIG_PATH=/projects/stbbsp/jayeshp/cm/CmLinux338xVer106_ps/userspace/gpl/apps/staging/usr/local/lib/pkgconfig
./configure     --host=mips-linux \
                --target=mips-linux \
                --build=i386-pc-linux-gnu  

