
#define _INO_T_DEFINED 1

#define HAVE_STDLIB_H  1
#define HAVE_STRING_H  1
#define HAVE_GETOPT_H  1
#define HAVE_ERRNO_H   1
#define HAVE_SETJMP_H  1

#define HAVE_STRCASECMP 1
#define strcasecmp     _stricmp
#define strncasecmp     _strnicmp

#define HAVE_CONIO_H   1

#define HAVE_EXT2_INODE_VERSION 1

#define inline __forceinline

#define _CTYPE_DISABLE_MACROS

