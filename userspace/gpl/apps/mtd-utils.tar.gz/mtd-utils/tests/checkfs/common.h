/* $Id: //depot/brcm/head/bcm963xx/userspace/gpl/apps/mtd-utils/tests/checkfs/common.h#1 $ */
//this .h file is common to both the file creation utility and
//the file checking utility.
#define TRUE    1
#define FALSE   0

#define MAX_NUM_FILES    100
