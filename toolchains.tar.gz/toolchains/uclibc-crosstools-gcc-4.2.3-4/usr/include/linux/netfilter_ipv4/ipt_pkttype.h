#ifndef _IPT_PKTTYPE_H
#define _IPT_PKTTYPE_H

#include <linux/netfilter/xt_pkttype.h>
#define ipt_pkttype_info xt_pkttype_info

#endif /*_IPT_PKTTYPE_H*/
