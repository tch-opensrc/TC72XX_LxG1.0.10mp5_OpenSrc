This is the Apps partition for 93383WVG.  Files copied into this directory 
will be compressed and stored as a JFFS2 filesystem image in the target
 folder (93383LxG).  The final step of the build creates a downloadable bin file called 
apps.bin, which can then be downloaded using the DOCSIS application.
